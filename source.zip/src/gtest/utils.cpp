int GenZero(int n)
{
    return 0;
}

int GenMax(int n)
{
    return n-1;
}
